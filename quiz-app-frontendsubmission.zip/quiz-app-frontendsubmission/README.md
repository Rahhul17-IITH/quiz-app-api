# Install dependencies (node modules)
npm install axios react-router-dom
npm install -D postcss autoprefixer
npm install tailwindcss@3
npx tailwindcss init -p

# Start your frontend server using:

npm start

# images of the application demo is in the frontend_images directory 