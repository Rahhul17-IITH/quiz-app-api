import React,{useEffect,useState} from 'react';
import API from '../api';
import {Link} from 'react-router-dom';

const QuizList=()=>{
 const[quizzes,setQuizzes]=useState([]);

 useEffect(()=>{
   API.get('/quizzes').then(res=>setQuizzes(res.data));
 },[]);

 return(
   <div className='max-w-lg mx-auto mt-10'>
     {quizzes.map(q=>(
       <div key={q._id}>
         📌<Link to={`/quiz/${q._id}`} className='text-blue-500'>{q.title}</Link>
       </div>))}
   </div>);
};

export default QuizList;
