import React, { useState } from 'react';
import API from '../api';
import { useNavigate, Link } from 'react-router-dom';

const Signup = () => {
  const [username,setUsername]=useState('');
  const [password,setPassword]=useState('');
  const navigate=useNavigate();

  const handleSignup=async()=>{
    try{
      await API.post('/auth/register',{username,password});
      alert('Signup successful! Please login.');
      navigate('/');
    }catch(error){
      alert('Signup failed!');
    }
  };

  return(
    <div className="max-w-md mx-auto mt-10 p-6 bg-white shadow-md rounded">
      <h2 className="text-xl font-bold mb-4">Sign Up</h2>
      <input className="border p-2 w-full mb-4" placeholder="Username" value={username} onChange={(e)=>setUsername(e.target.value)} />
      <input type="password" className="border p-2 w-full mb-4" placeholder="Password" value={password} onChange={(e)=>setPassword(e.target.value)} />
      <button className="bg-green-500 text-white p-2 w-full" onClick={handleSignup}>Sign Up</button>
      <p className="mt-3">Already have an account? <Link className="text-blue-500" to="/">Login</Link></p>
    </div>
  );
};

export default Signup;
