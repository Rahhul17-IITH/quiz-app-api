import React,{useState} from 'react';
import API from '../api';

const CreateQuiz=()=>{
 const [title,setTitle]=useState('');

 const createQuiz=async()=>{
   try{
     await API.post('/quizzes',{title,questions:[]});
     alert('Quiz created!');
   }catch(err){
     alert('Failed to create quiz');
   }
 };

 return(
   <div className="max-w-md mx-auto mt-10">
     <input placeholder='Quiz Title' value={title} onChange={(e)=>setTitle(e.target.value)} className='border p-2 w-full'/>
     <button onClick={createQuiz} className='bg-blue-500 text-white p-2 mt-3'>Create Quiz</button>
   </div>
 );
};

export default CreateQuiz;
