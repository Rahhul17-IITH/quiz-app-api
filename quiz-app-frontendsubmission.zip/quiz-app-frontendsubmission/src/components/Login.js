import React, { useState } from 'react';
import API from '../api';
import { useNavigate, Link } from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await API.post('/auth/login', { username, password });
      localStorage.setItem('token', res.data.token);
      navigate('/dashboard');
    } catch (error) {
      alert('Login failed!');
    }
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 bg-white shadow-md rounded">
      <h2 className="text-xl font-bold mb-4">Login</h2>
      <input className="border p-2 w-full mb-4" placeholder="Username" value={username} onChange={(e)=>setUsername(e.target.value)} />
      <input type="password" className="border p-2 w-full mb-4" placeholder="Password" value={password} onChange={(e)=>setPassword(e.target.value)} />
      <button className="bg-blue-500 text-white p-2 w-full" onClick={handleLogin}>Login</button>
      <p className="mt-3">Don't have an account? <Link className="text-blue-500" to="/signup">Sign Up</Link></p>
    </div>
  );
};

export default Login;
